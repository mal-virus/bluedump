# bluedump
Install on a debian based machine with access to bluetooth.
More info to come.

curl -sSL https://github.com/mal-virus/bluedump/raw/master/inst.bluedump | sh
